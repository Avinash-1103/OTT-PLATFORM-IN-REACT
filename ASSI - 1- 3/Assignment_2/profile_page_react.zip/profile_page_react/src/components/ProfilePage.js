
import React from 'react';
import ProfilePicture from './ProfilePicture';
import ProfileDetails from './ProfileDetails';

const ProfilePage = () => {
  const user = {
    name: 'John Doe',
    email: 'john.doe@example.com',
    bio: 'A passionate web developer.',
    profilePicture: 'https://via.placeholder.com/150'
  };

  return (
    <div className="profile-page">
      <ProfilePicture profilePicture={user.profilePicture} />
      <ProfileDetails name={user.name} email={user.email} bio={user.bio} />
    </div>
  );
};

export default ProfilePage;
