
import React from 'react';
import './ProfilePicture.css';

const ProfilePicture = ({ profilePicture }) => {
  return (
    <div className="profile-picture">
      <img src={profilePicture} alt="Profile" />
    </div>
  );
};

export default ProfilePicture;
