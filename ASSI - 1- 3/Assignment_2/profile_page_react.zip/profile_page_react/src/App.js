
import React from 'react';
import './App.css';
import ProfilePage from './components/ProfilePage';

function App() {
  return (
    <div className="App">
      <ProfilePage />
    </div>
  );
}

export default App;
